﻿using System;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using ZXing.Net.Mobile.Forms;

namespace XamarinQRApp
{
    public partial class App : Application
    {
        public App()
        {
            InitializeComponent();
         //   MainPage = new XamarinQRApp.MyCalendarX();
            MainPage = new NavigationPage(new MainPage());
        }

        protected override void OnStart()
        {
        }

        protected override void OnSleep()
        {
        }

        protected override void OnResume()
        {
        }
    }
}
